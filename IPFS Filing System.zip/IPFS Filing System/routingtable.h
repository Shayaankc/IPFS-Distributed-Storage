#pragma once

#include"Machine.h"

class machinenode;  //to get to use the class machine node

class RT_Node
{
public:

	int data;   //for storing key
	machinenode* add;   //to store the address of machine node
	RT_Node* prev;  //to store prev Routing table node
	RT_Node* next;  //to store next Routing table node

	RT_Node()   //defualt constructor for RT_Node
	{
		data = 0;
		add = nullptr;
		prev = nullptr;
		next = nullptr;
	}
};


class routing_table //main class of routing table
{

public:
	RT_Node* head;  //head node

	routing_table() //defualt constructor of routing table
	{
		head = nullptr;
	}

	void insertEnd(int MID, machinenode* Madd)  //inserting at end at every insert
	{
		RT_Node* Nodenew = new RT_Node;
		Nodenew->data = MID;
		Nodenew->add = Madd;

		if (!head)  //if its the first insert
		{
			head = Nodenew;
		}
		else    //find the last position to insert at
		{
			RT_Node* Curr = head;
			while (Curr->next) {
				Curr = Curr->next;
			}
			Curr->next = Nodenew;
			Nodenew->prev = Curr;
		}
	}

	void display()  //display the routing/finger table
	{
		RT_Node* Curr = head;
		while (Curr) {
			cout << Curr->data << " ";
			Curr = Curr->next;
		}
		cout << endl;
	}
};