#pragma once
#include <iostream>
using namespace std;
#include<fstream>
#include<string>
class BTreeNode
{
public:

	int* keys;				//array of keys
	string* name_of_file;	//array of names 
	int min_degree;			//minimum degree of tree
	BTreeNode** array1;		//array of children pointers
	int num_keys;			//number of current keys in a node
	bool leaf;				//check to see if a node is a leaf or not

	BTreeNode(int d, bool leaf1)
	{
		min_degree = d;
		leaf = leaf1;

		keys = new int[2 * min_degree - 1];
		array1 = new BTreeNode * [2 * min_degree];
		num_keys = 0;
		name_of_file = new string[2 * min_degree - 1];
	}

	void insertNonFull(int inputk, const string& file_name)		//inserts key along with name in tree
	{
		int temp = num_keys - 1;

		if (leaf == true)
		{
			while (temp >= 0 && keys[temp] > inputk)
			{
				keys[temp + 1] = keys[temp];
				name_of_file[temp + 1] = name_of_file[temp];
				temp--;
			}
			keys[temp + 1] = inputk;
			name_of_file[temp + 1] = file_name;
			num_keys = num_keys + 1;
		}
		else
		{
			while (temp >= 0 && keys[temp] > inputk)
				temp--;
			if (array1[temp + 1]->num_keys == 2 * min_degree - 1)
			{
				splitChild(temp + 1, array1[temp + 1]);

				if (keys[temp + 1] < inputk)
					temp++;
			}
			array1[temp + 1]->insertNonFull(inputk, file_name);
		}
	}

	void splitChild(int i, BTreeNode* y)	//splits child if node full during insertion
	{
		BTreeNode* z = new BTreeNode(y->min_degree, y->leaf);
		z->num_keys = min_degree - 1;

		for (int j = 0; j < min_degree - 1; j++)
		{
			z->keys[j] = y->keys[j + min_degree];
			z->name_of_file[j] = y->name_of_file[j + min_degree];

		}

		if (y->leaf == false)
		{
			for (int j = 0; j < min_degree; j++)
				z->array1[j] = y->array1[j + min_degree];
		}

		y->num_keys = min_degree - 1;

		for (int j = num_keys; j >= i + 1; j--)
			array1[j + 1] = array1[j];

		array1[i + 1] = z;

		for (int j = num_keys - 1; j >= i; j--)
		{
			keys[j + 1] = keys[j];
			name_of_file[j + 1] = name_of_file[j];
		}

		keys[i] = y->keys[min_degree - 1];
		name_of_file[i] = y->name_of_file[min_degree - 1];


		num_keys = num_keys + 1;
	}

	void traverse()	  //print
	{
		int i;
		for (i = 0; i < num_keys; i++)
		{
			if (leaf == false)
				array1[i]->traverse();
			cout << " " << keys[i] << " " << name_of_file[i] << endl;;
		}

		if (leaf == false)
			array1[i]->traverse();
	}

	int findKey(int inputk)		//finds index of key
	{
		int index = 0;
		while (index < num_keys && keys[index] < inputk)
			index++;
		return index;
	}

	void deletion(int inputk, const string& file_name)
	{
		int index = findKey(inputk);

		if (index < num_keys && keys[index] == inputk && name_of_file[index] == file_name)
		{
			if (leaf)
				removeFromLeaf(index);
			else
				removeFromNonLeaf(index);
		}
		else
		{
			if (leaf)
			{
				cout << "The key " << inputk << " with file name " << file_name << " does not exist in the tree." << endl;
				return;
			}

			bool flag = ((index == num_keys) ? true : false);

			if (array1[index]->num_keys < min_degree)
				fill(index);

			if (flag && index > num_keys)
				array1[index - 1]->deletion(inputk, file_name);
			else
				array1[index]->deletion(inputk, file_name);
		}
		return;
	}

	void removeFromLeaf(int index) //for when what u want to remove is at leaf node
	{
		for (int i = index + 1; i < num_keys; ++i)
		{
			keys[i - 1] = keys[i];
			name_of_file[i - 1] = name_of_file[i];
		}

		num_keys--;

		return;
	}

	void removeFromNonLeaf(int index) //when not at leaf node
	{
		int k = keys[index];

		if (array1[index]->num_keys >= min_degree)
		{
			int pred = getPredecessor(index);
			keys[index] = pred;
			array1[index]->deletion(pred, name_of_file[index]);
		}

		else if (array1[index + 1]->num_keys >= min_degree)
		{
			int succ = getSuccessor(index);
			keys[index] = succ;
			array1[index + 1]->deletion(succ, name_of_file[index]);
		}

		else
		{
			merge(index);
			array1[index]->deletion(k, name_of_file[index]);
		}
		return;
	}

	int getPredecessor(int index) //gets predecessor of key value of index
	{
		BTreeNode* cur = array1[index];
		while (!cur->leaf)
			cur = cur->array1[cur->num_keys];

		return cur->keys[cur->num_keys - 1];
	}

	int getSuccessor(int index) //gets successor of key value of index
	{
		BTreeNode* cur = array1[index + 1];
		while (!cur->leaf)
			cur = cur->array1[0];

		return cur->keys[0];
	}

	void fill(int index)	//fills a child node 
	{
		if (index != 0 && array1[index - 1]->num_keys >= min_degree)
			borrowFromPrev(index);

		else if (index != num_keys && array1[index + 1]->num_keys >= min_degree)
			borrowFromNext(index);

		else
		{
			if (index != num_keys)
				merge(index);
			else
				merge(index - 1);
		}
		return;
	}

	void borrowFromPrev(int index)	//borrows key from prev sibling
	{
		BTreeNode* child = array1[index];
		BTreeNode* sibling = array1[index - 1];

		for (int i = child->num_keys - 1; i >= 0; --i)
			child->keys[i + 1] = child->keys[i];

		if (!child->leaf)
		{
			for (int i = child->num_keys; i >= 0; --i)
				child->array1[i + 1] = child->array1[i];
		}

		child->keys[0] = keys[index - 1];

		if (!child->leaf)
			child->array1[0] = sibling->array1[sibling->num_keys];

		keys[index - 1] = sibling->keys[sibling->num_keys - 1];

		child->num_keys += 1;
		sibling->num_keys -= 1;

		return;
	}

	void borrowFromNext(int index)	 //borrows key from next sibling
	{
		BTreeNode* child = array1[index];
		BTreeNode* sibling = array1[index + 1];

		child->keys[(child->num_keys)] = keys[index];

		if (!(child->leaf))
			child->array1[(child->num_keys) + 1] = sibling->array1[0];

		keys[index] = sibling->keys[0];

		for (int i = 1; i < sibling->num_keys; ++i)
			sibling->keys[i - 1] = sibling->keys[i];

		if (!sibling->leaf) {
			for (int i = 1; i <= sibling->num_keys; ++i)
				sibling->array1[i - 1] = sibling->array1[i];
		}

		child->num_keys += 1;
		sibling->num_keys -= 1;

		return;
	}

	void merge(int index)	//merges node with sibling
	{
		BTreeNode* child = array1[index];
		BTreeNode* sibling = array1[index + 1];

		child->keys[min_degree - 1] = keys[index];

		for (int i = 0; i < sibling->num_keys; ++i)
			child->keys[i + min_degree] = sibling->keys[i];

		if (!child->leaf) {
			for (int i = 0; i <= sibling->num_keys; ++i)
				child->array1[i + min_degree] = sibling->array1[i];
		}

		for (int i = index + 1; i < num_keys; ++i)
			keys[i - 1] = keys[i];

		for (int i = index + 2; i <= num_keys; ++i)
			array1[i - 1] = array1[i];

		child->num_keys += sibling->num_keys + 1;
		num_keys--;

		delete (sibling);
		return;
	}

	friend class BTree;
};

class BTree {

public:

	BTreeNode* root;
	int min_degree;

	BTree(int d)
	{
		root = NULL;
		min_degree = d;
	}

	void traverse()		//calls the node traverse ftn
	{
		if (root != NULL)
			root->traverse();
	}

	void insertion(int inputk, const string& file_name)		//insertion ftn
	{
		if (root == NULL)
		{
			root = new BTreeNode(min_degree, true);
			root->keys[0] = inputk;
			root->name_of_file[0] = file_name;
			root->num_keys = 1;
		}
		else {
			if (root->num_keys == 2 * min_degree - 1) {
				BTreeNode* s = new BTreeNode(min_degree, false);

				s->array1[0] = root;

				s->splitChild(0, root);

				int i = 0;
				if (s->keys[0] < inputk)
					i++;
				s->array1[i]->insertNonFull(inputk, file_name);

				root = s;
			}
			else
				root->insertNonFull(inputk, file_name);
		}
	}

	void deleteByFileNameHelper(BTreeNode* bnode, const string& file_name)	//helper for deletion by name as node also passed
	{
		if (!bnode)
			return;

		for (int i = 0; i < bnode->num_keys; ++i)
		{
			if (bnode->name_of_file[i] == file_name)
			{
				bnode->removeFromLeaf(i);
				--i;
			}
		}
		if (!bnode->leaf)
		{
			for (int i = 0; i <= bnode->num_keys; ++i)
			{
				deleteByFileNameHelper(bnode->array1[i], file_name);
			}
		}
		if (bnode == root && bnode->num_keys == 0)
		{
			root = NULL;
		}
	}

	void deleteByFileName(const string& file_name)		//main deletion ftn
	{
		if (!root)
		{
			cout << "Tree is empty." << endl;
			return;
		}
		deleteByFileNameHelper(root, file_name);
	}

	bool searchKey(int kinput)		//searches if a key is in a tree or not
	{
		return searchKeyHelper(root, kinput);
	}

	bool searchKeyHelper(BTreeNode* bnode, int kinput) 	//helper for search as node also passed
	{
		if (!bnode)
		{
			return false;
		}
		int index = bnode->findKey(kinput);

		if (index < bnode->num_keys && bnode->keys[index] == kinput)
		{
			return true;
		}
		if (bnode->leaf) {
			return false;
		}

		return searchKeyHelper(bnode->array1[index], kinput);
	}

	string findFileByLesserKey(int MID)		//Find name of file which has key lesser that key passed
	{
		if (!root || MID <= root->keys[0])
		{
			return "-1";
		}

		BTreeNode* current = root;
		int index = -1;

		while (current)
		{
			int i = 0;
			while (i < current->num_keys && current->keys[i] < MID)
			{
				index++;
				i++;
			}

			if (current->leaf || i == 0)
			{
				break;
			}

			current = current->array1[i];
		}

		if (index >= 0 && index < root->num_keys)
		{
			return root->name_of_file[index];
		}
		else
		{
			return "-1";
		}
	}

	bool isBTreeEmpty()		//checks if tree is empy
	{
		if (root == nullptr)
			return true;
		else
			return false;
	}

	string getRootFileName()	//return filename at root
	{
		if (isBTreeEmpty())
		{
			return "";
		}

		return root->name_of_file[0];
	}

	int getRootFileKey()	//return key at root
	{
		if (isBTreeEmpty())
		{
			return -1;
		}

		return root->keys[0];
	}

};