#pragma once
#include<iostream>
#include<string>
#include"hash.h"
#include"BTree.h"
#include"routingtable.h"

using namespace std;

int ID = 0;		// global variable to get the id to each machine even if its active or not
class routing_table;	// to get access to the lass routing table

class machinenode	// the class for machine nodes
{

public:

	BTree* Tree;	// B-Tree to store file data in the machine
	machinenode* next;	// to get to the next machine
	string Machine_name;	// to get the machine name
	bool active;	// checking if the machine is active or not
	int machineID;	// to give machineID to each machine
	routing_table* FT;	// Finger table or routing table

	machinenode()	// default constructor
	{
		Machine_name = "";
		Tree = nullptr;
		next = nullptr;
		active = 0;
		machineID = 0;
		FT = new routing_table;
	}

};


class machine	// the main machine class
{
public:

	machinenode* head;	// head of machine node
	int Order_of_tree;	// order of B tree in machine node

	machine(int i)	// constructor for machine node
	{
		head = nullptr;	// head nullptr at first
		Order_of_tree = i;
	}

	machinenode* getHead()	// to get us the head of machine nodes
	{
		return head;
	}

	void insert()	// insert a machine node into the circular linked list
	{
		if (head == nullptr)	// if it was the first insert
		{
			head = new machinenode();
			head->machineID = ID;
			ID++;
			head->next = head;
		}
		else	//keep going until the last position is found and start changing in there
		{
			machinenode* T = head;
			while (T->next != head)
			{
				T = T->next;
			}
			machinenode* T2 = new machinenode;
			T2->machineID = ID;
			ID++;
			T->next = T2;
			T2->next = head;

		}
	}

	void print()	//print all the machines and to see if they are active or not
	{
		machinenode* T = head;
		if (T != nullptr)
		{
			cout << "Machine ID: " << T->machineID << " Active: " << T->active << "  " << endl;
			T = T->next;
		}
		while (T != head)
		{
			cout << "Machine ID: " << T->machineID << " Active: " << T->active << "  " << endl;
			T = T->next;
		}
		cout << endl;
	}

	void AtIndex(string machine_n, int machine_id)	//this is for activating the machine at that index
	{

		machinenode* T = head;

		if (T->machineID == machine_id)
		{
			T->active = 1;
			T->Machine_name = machine_n;
			return;
		}
		T = T->next;

		while (T != head)
		{
			if (T->machineID == machine_id)
			{
				T->active = 1;
				T->Machine_name = machine_n;
				break;
			}

			T = T->next;
		}
	}


	bool Machine_Active(int MID) //activating a machine only by its id
	{
		machinenode* T = head;

		if (T->machineID == MID)
		{
			return 1;
		}
		T = T->next;
		while (T != head)
		{
			if (T->machineID == MID)
			{
				if (T->active == 0)
					return 0;
				else
					return 1;
				break;
			}

			T = T->next;
		}
		return 0;
	}

	machinenode* IDfind(int findid)	//finding machine node by its id
	{
		machinenode* t = head;

		while (t != nullptr)
		{
			if (t->machineID == findid)
			{
				return t;
			}
			t = t->next;
			if (t == head)
			{
				break;
			}
		}
		return nullptr;
	}

	machinenode* findingrightmachine(int machine_key) //finding machine node by its key
	{
		machinenode* T = head;    //to start getting the traversal
		machinenode* ANS;    //for returning the node

		while (1)
		{
			if (T->active == 1)
			{
				break;
			}
			T = T->next;
		}

		int i = 1;
		RT_Node* tempf = T->FT->head;

		if (machine_key <= T->machineID)
		{
			ANS = T;
			cout << "The right machine for this is " << ANS->machineID << endl;
			return ANS;
		}

		while (1)
		{
			cout << "the path was " << tempf->data << endl;

			if (machine_key > tempf->data && tempf->next == nullptr)
			{
				ANS = tempf->add;
				break;
			}
			else if (machine_key < tempf->data && i == 1)
			{
				ANS = tempf->add;
				break;
			}
			else if (tempf->data == machine_key)
			{
				ANS = tempf->add;
				break;
			}
			else if (machine_key > tempf->data && tempf->next == nullptr)
			{
				tempf = tempf->add->FT->head;
			}
			else if (machine_key > tempf->data)
			{
				tempf = tempf->next;
			}
			else if (machine_key < tempf->data)
			{
				tempf = tempf->prev;
				tempf = tempf->add->FT->head;
				i = 1;
				continue;
			}

			i++;
		}
		cout << "The right machine for this is " << ANS->machineID << endl;
		return ANS;
	}

	machinenode* searchfolder(string foldernamestr) //this one searches the machine by its name which 
	{												//in general is the folder name
		machinenode* t = head;

		while (1)
		{
			if (t->active == 1)
				break;
			t = t->next;
		}
		int i = 0;
		while (1)
		{
			if (t->Machine_name == foldernamestr)
				break;

			if (i == 100)
				break;
			t = t->FT->head->add;
			i++;
		}
		if (i == 100)
		{
			return nullptr;
		}
		else
		{
			return t;
		}

	}

	void printing_all_active_machines()
	{
		machinenode* t = head;
		int FirstID;
		while (1)
		{
			if (t->active == 1)
				break;
			t = t->next;
		}
		FirstID = t->machineID;

		while (1)
		{
			cout << "Machine Name: " << t->Machine_name << "   Machine ID: " << t->machineID << endl;

			t = t->FT->head->add;

			if (t->machineID == FirstID)
				break;
		}

	}

};

void generate_routing_table(int nom, machinenode* head1, int maxbits)
{
	//this function generates routing table of each of the machines that are active in our
	//curcular linked list

	int i1 = 1;
	int z1;
	int j1;

	while (i1 <= nom)
	{

		machinenode* temp2 = head1;
		z1 = pow(2, i1 - 1);
		j1 = head1->machineID + z1;
		j1 = j1 % maxbits;

		while (temp2->machineID != j1)
		{
			temp2 = temp2->next;
		}
		while (temp2->active == 0)
		{
			temp2 = temp2->next;
		}

		head1->FT->insertEnd(temp2->machineID, temp2);

		i1++;
	}


}

void generate_routing_table2(int nom, machinenode* head1, int maxbits)
{
	//this function generates routing table of each of the machines that are active in our
	//curcular linked list
	head1->FT = new routing_table;

	int i1 = 1;
	int z1;
	int j1;

	while (i1 <= nom)
	{

		machinenode* temp2 = head1;
		z1 = pow(2, i1 - 1);
		j1 = head1->machineID + z1;
		j1 = j1 % maxbits;

		while (temp2->machineID != j1)
		{
			temp2 = temp2->next;
		}
		while (temp2->active == 0)
		{
			temp2 = temp2->next;
		}

		head1->FT->insertEnd(temp2->machineID, temp2);

		i1++;
	}


}