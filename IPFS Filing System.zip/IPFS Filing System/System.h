#pragma once

#include "Machine.h"
#include<cmath>
#include<time.h>
#include"hash.h"
#include <filesystem>	//for adding or deleting directories
#include <windows.h>	//for folder handling
#include <fstream>	//for file handling
#include <locale> //fr converting wstring to string
#include <codecvt> //fr converting wstring to string
#include <cstdlib> //for system("cls") (clearing screen)

using namespace std;

bool deleteFolder(const  wstring& PFpath, const  wstring& Fname)
{

	wstring path = PFpath + Fname;//creates the path of the folder

	if (RemoveDirectoryW(path.c_str())) //this delets the directorey in the folder
	{
		wcout << L"Folder '" << PFpath << L"' deleted successfully." << endl;

		return true;
	}
	else 
	{
		DWORD error = GetLastError();//if the directory is not deleted then give out an error

		if (error == ERROR_FILE_NOT_FOUND) //if the folder is not found on that path
		{
			wcerr << L"Folder '" << PFpath << L"' not found." << endl;
		}
		else //if there was error in deleting the folder on that path
		{
			wcerr << L"Error deleting folder. Error code: " << error << endl;
		}


		return false;
	}
}

string wstringToString(const  wstring& wstr_string)
{
	//this function converts a wstring to simple string
	wstring_convert< codecvt_utf8<wchar_t>, wchar_t> converter;

	return converter.to_bytes(wstr_string);
}



bool fileExists(const  string& na_of_file)
{
	DWORD attributes = GetFileAttributesA(na_of_file.c_str());

	return (attributes != INVALID_FILE_ATTRIBUTES && !(attributes & FILE_ATTRIBUTE_DIRECTORY));
}

wstring stringToWstring(const  string& simple_str)
{	//this function converts a simple string to wstring
	int Size = MultiByteToWideChar(CP_UTF8, 0, simple_str.c_str(), -1, NULL, 0);

	wchar_t* wStr = new wchar_t[Size];

	MultiByteToWideChar(CP_UTF8, 0, simple_str.c_str(), -1, wStr, Size);

	wstring result(wStr);

	delete[] wStr;

	return result;
}

void createFolder(const  wstring& PFfolder, const  wstring& Fname) 
{
	//this function creates a new folder into a folder named Machines
	wstring Fpath = PFfolder + L"\\" + Fname;
	//getting the full path for the folder
	
	if (CreateDirectory(Fpath.c_str(), NULL) || ERROR_ALREADY_EXISTS == GetLastError())
	{//if the folder is created successfully
		wcout << L"Folder created successfully: " << Fpath << endl;
	}
	else 
	{//if there was some problem while creating the folder
		wcerr << L"Failed to create folder: " << Fpath << endl;
	}
}

void createFileInMachineFolder(const  string& Macname, const  string& Fname, const  string& full_data)
{
	//this function creates a file in the machine folder
	string mFolderPath = "Machines/" + Macname;
	//this gets us the path for the machine folder

	
	string fPath = mFolderPath + "/" + Fname;
	//this gives us the oath for the file in machine folder
	
	ofstream OF(fPath);

	if (OF.is_open())
	{
		//write all of the data in the filde
		OF << full_data;

		OF.close();

		cout << "File created successfully: " << fPath << endl;
	}
	else 
	{	//if there was some problem opening or creating the file
		cerr << "Error: Unable to create file." << endl;
	}
}
void deleteFileInMachineFolder(const string& macName, const string& fName)
{
	//this function deletes the file from the machine folder

	string mFolderPath = "Machines/" + macName;
	string fPath = mFolderPath + "/" + fName;

	if (remove(fPath.c_str()) != 0)
	{
		cerr << "Error deleting the file: " << fPath << endl;
	}
	else
	{
		cout << "File " << fName << " in machine " << macName << " successfully deleted." << endl;
	}
}

class IPFS
{
public:
	int bitnum;
	int no_of_machines;
	int BTREEOrder;
	int max_nom;
	int no_of_files;

	IPFS()
	{
		bitnum = 0;
		no_of_machines = 0;
		BTREEOrder = 0;
		max_nom = 0;
		no_of_files = 0;
	}
	void main_loop_working()
	{
		cout << "\t\tEntering name of machines " << endl << endl;

		srand(time(0));

		machine M(BTREEOrder);
		max_nom = pow(2, bitnum);
		int total_machines = max_nom;
		int total_bits = max_nom;
		while (total_machines > 0)
		{
			M.insert();
			total_machines--;
		}

		int MAC_ASS = no_of_machines;
		int i = 1;
		string Mname;
		int MID;
		char IDchoice;
		while (MAC_ASS > 0)
		{
			cout << "Enter the name of machine " << i << ": ";
			cin >> Mname;
			string folderName = Mname;
			string parentFolder = "Machines";
			createFolder(stringToWstring(parentFolder), stringToWstring(folderName));
			cout << "Do you want to assign ID manually or automatically(Y/N): ";
			cin >> IDchoice;
			while (IDchoice != 'Y' && IDchoice != 'y' && IDchoice != 'N' && IDchoice != 'n')
			{
				cout << "Invalid choice, Please Enter again" << endl;
				cout << "Do you want to assign ID manually or automatically(Y/N): ";
				cin >> IDchoice;
			}
			if (IDchoice == 'Y' || IDchoice == 'y')
			{
				cout << "Enter the Id you want for " << Mname << " : ";
				cin >> MID;
				MID = MID % max_nom;

				while (M.Machine_Active(MID) == 1)
				{
					MID++;
					MID = MID % max_nom;
				}
				M.AtIndex(Mname, MID);
				cout << endl;
			}
			else
			{
				string temp;
				SHA1 Tsha1;//doing this to reset the hash function
				temp = Tsha1.calculateHash(Mname);
				MID = calculateModMaxHash(temp);
				cout << "Hash generated of the machine name: " << temp << endl;
				cout << "ID of the machine generated: " << MID << endl << endl;
				while (M.Machine_Active(MID) == 1)
				{
					MID++;
					MID = MID % max_nom;
				}
				M.AtIndex(Mname, MID);
			}
			MAC_ASS--;
			i++;
		}
		machinenode* temp = M.head;
		for (int i = 0; i < max_nom; i++)
		{
			if (temp->active == 1)
			{
				generate_routing_table(no_of_machines, temp, max_nom);
			}
			temp = temp->next;
		}
		for (int i = 0; i < max_nom; i++)
		{
			if (temp->active == 1)
			{
				temp->Tree = new BTree(BTREEOrder);
			}
			temp = temp->next;
		}
		system("cls");

		bool exitloop = true;
		string name1;
		int option = 0;
		while (exitloop)
		{
			cout << "What would you like to do?" << endl << endl;
			cout << "1 - Add a new machine to the system" << endl;
			cout << "2 - Delete a Machine from the system" << endl;
			cout << "3 - Input file into the system" << endl;
			cout << "4 - Search file from the system" << endl;
			cout << "5 - Delete file from the system" << endl;
			cout << "6 - Print BTREE of a machine" << endl;
			cout << "7 - Print Routing Table of a machine " << endl;
			cout << "8 - Print all the active machines" << endl;
			cout << "9 - Exit" << endl;
			cout << endl << "Option: ";
			cin >> option;

			
			if (option == 1)    //adding machine
			{
				no_of_machines++;
				if (no_of_machines > max_nom)
				{
					cout << "Cannot add more machines " << endl;
					no_of_machines--;
				}
				else
				{
					machinenode* mnode;
					cout << "Enter the name of machine " << i << ": ";
					cin >> Mname;
					string folderName = Mname;
					string parentFolder = "Machines";
					createFolder(stringToWstring(parentFolder), stringToWstring(folderName));
					cout << "Do you want to assign ID manually or automatically(Y/N): ";
					cin >> IDchoice;
					while (IDchoice != 'Y' && IDchoice != 'y' && IDchoice != 'N' && IDchoice != 'n')
					{
						cout << "Invalid choice, Please Enter again" << endl;
						cout << "Do you want to assign ID manually or automatically(Y/N): ";
						cin >> IDchoice;
					}
					if (IDchoice == 'Y' || IDchoice == 'y')
					{
						cout << "Enter the Id you want for " << Mname << " : ";
						cin >> MID;
						MID = MID % max_nom;

						while (M.Machine_Active(MID) == 1)
						{
							MID++;
							MID = MID % max_nom;
						}
						mnode = M.IDfind(MID);
					}
					else
					{
						string temp;
						SHA1 Tsha1;
						temp = Tsha1.calculateHash(Mname);
						MID = calculateModMaxHash(temp);
						cout << "Hash generated of the machine name:" << temp << endl;
						cout << "ID of the machine generated:" << MID << endl << endl;
						while (M.Machine_Active(MID) == 1)
						{
							MID++;
							MID = MID % max_nom;
						}
						mnode = M.IDfind(MID);
					}
					mnode->active = true;
					mnode->Machine_name = Mname;
					mnode->Tree = new BTree(BTREEOrder);

					machinenode* temp = M.head;
					for (int i = 0; i < max_nom; i++)
					{
						if (temp->active == 1)
						{
							generate_routing_table2(no_of_machines, temp, max_nom);
						}
						temp = temp->next;
					}
					machinenode* temp1 = mnode->FT->head->add;

					

					bool loopstop = true;
					while (loopstop)
					{
						string nameoffile;

						if (temp1->Tree->findFileByLesserKey(MID) == "-1")
						{
							loopstop = false;
						}
						else
						{
							nameoffile = temp1->Tree->findFileByLesserKey(MID);

							string filename;
							int filekey;
							SHA1 sha12;
							string Hashedkey;
							string filename1 = nameoffile;
							string filepath = "input/" + nameoffile;

							machinenode* TM1;
							string filedata = readFile(filepath);
							Hashedkey = sha12.calculateHash(filedata);
							filekey = calculateModMaxHash(Hashedkey);
							TM1 = M.findingrightmachine(filekey);
							cout << endl;
							temp1->Tree->traverse();
							cout << endl;
							temp1->Tree->deleteByFileName(nameoffile);
							cout << endl;
							temp1->Tree->traverse();
							cout << endl;
							deleteFileInMachineFolder(temp1->Machine_name, filename1);

							cout << endl << "Moving file" << filename1 << "from machine: '" << temp1->Machine_name << "' to machine: '" << mnode->Machine_name << "' " << endl;

							mnode->Tree->insertion(filekey, filename1);
							createFileInMachineFolder(mnode->Machine_name, filename1, filedata);

						}
					}
					cout << endl << "Machine '" << mnode->Machine_name << "' ID: '" << mnode->machineID << "' was added successfully" << endl << endl ;

				}
			}
			else if (option == 2)   //deleting a machine
			{
				wstring folderName1;
				string foldernamestr;
				wstring parentFolderPath = L"Machines\\";
				machinenode* mnode;
				cout << "Enter the name of machine to be deleted: ";
				wcin >> folderName1;

				foldernamestr = wstringToString(folderName1);
				machinenode* temp1;
				machinenode* succ1;
				string fileswitch;
				int keyswitch;
				temp1 = M.searchfolder(foldernamestr);


				succ1 = temp1->FT->head->add;
				while (temp1->Tree->isBTreeEmpty() == 0)
				{
					fileswitch = temp1->Tree->getRootFileName();
					keyswitch = temp1->Tree->getRootFileKey();
					succ1->Tree->insertion(keyswitch, fileswitch);
					string filepath = "input/" + fileswitch;
					string filedata = readFile(filepath);
					createFileInMachineFolder(succ1->Machine_name, fileswitch, filedata);
					temp1->Tree->deleteByFileName(fileswitch);
					deleteFileInMachineFolder(temp1->Machine_name, fileswitch);
				}
				deleteFolder(parentFolderPath, folderName1);

				cout << "Machine '" << temp1->Machine_name << "' ID: '" << temp1->machineID << "' was deleted successfully" << endl << endl;
			}
			else if (option == 3)   //input a file
			{

				no_of_files++;
				if (no_of_files > max_nom)
				{
					cout << "Cannot add more files " << endl;
					no_of_files--;
				}
				else
				{
					cout << "What file do u want to input: ";
					cin >> name1;

					name1 = name1 + ".txt";
					string filepath = "input/" + name1;

					if (fileExists(filepath))
					{
						cout << "File exists. Proceed with reading." << endl;
					}
					else
					{
						cout << "Error: File does not exist." << endl;
					}
					int filekey;
					SHA1 sha12;

					string Hashedkey;

					machinenode* TM;
					string filedata = readFile(filepath);
					Hashedkey = sha12.calculateHash(filedata);
					filekey = calculateModMaxHash(Hashedkey);
					cout << endl;
					cout << "SHA1 generated: " << Hashedkey << endl;
					cout << "File Key generated: " << filekey << endl;
					TM = M.findingrightmachine(filekey);
					TM->Tree->insertion(filekey, name1);

					cout << "Successful insertion in Machine: "<< TM->Machine_name << "  ID: " << TM->machineID << endl;
					TM->Tree->traverse();
					cout << endl;

					createFileInMachineFolder(TM->Machine_name, name1, filedata);
				}

			}
			else if (option == 4)   //searching file
			{
				string filename;
				int filekey;
				SHA1 sha12;
				string Hashedkey;

				cout << "Enter the name of the file you want to search: ";
				cin >> filename;
				string filename1 = filename;
				filename = filename + ".txt";
				string filepath = "input/" + filename;

				machinenode* TM1;
				string filedata = readFile(filepath);
				Hashedkey = sha12.calculateHash(filedata);
				filekey = calculateModMaxHash(Hashedkey);
				TM1 = M.findingrightmachine(filekey);

				string machinefolderpath = "Machines/" + TM1->Machine_name;
				string filepath1 = machinefolderpath + "/" + filename1 + ".txt";
				if (!TM1->Tree->searchKey(filekey))
				{
					cout << " Error! The file you searched couldn't be found " << endl;
				}
				else
				{
					cout << "File Path: " << filepath1 << endl;
					cout << "File Data: " << filedata << endl;
				}
			}
			else if (option == 5)	//delete file
			{
				string filename;
				int filekey;
				SHA1 sha12;
				string Hashedkey;

				cout << "Enter the name of the file you want to delete: ";
				cin >> filename;
				string filename1 = filename;
				filename = filename + ".txt";
				string filepath = "input/" + filename;

				machinenode* TM1;
				string filedata = readFile(filepath);
				Hashedkey = sha12.calculateHash(filedata);
				filekey = calculateModMaxHash(Hashedkey);
				TM1 = M.findingrightmachine(filekey);
				cout << endl;
				TM1->Tree->traverse();
				cout << endl;
				TM1->Tree->deleteByFileName(filename);
				cout << endl;
				cout << "Filename: " << filename << endl;
				TM1->Tree->traverse();
				cout << endl;



				deleteFileInMachineFolder(TM1->Machine_name, filename);

			}
			else if (option == 6)
			{
				char C;
				cout << "Will you enter the name of machine ('N') or ID of the machine ('I'):";
				cin >> C;

				if (C == 'n' || C == 'N')
				{
					machinenode* TE1;
					string MNAME;
					cout << "Enter the Name of the folder you want Btree of : ";
					cin >> MNAME;
					TE1 = M.searchfolder(MNAME);
					cout << "The BTREE of the machine " << TE1->Machine_name << " :" << endl;
					TE1->Tree->traverse();
				}
				else if (C == 'i' || C == 'I')
				{
					machinenode* TE1;
					int MAID;
					cout << "Enter the ID of the folder you want Btree of : ";
					cin >> MAID;
					TE1 = M.IDfind(MAID);
					cout << "The BTREE of the machine " << TE1->Machine_name << " :" << endl;
					TE1->Tree->traverse();
				}
			}
			else if (option == 7)
			{
				char C;
				cout << "Will you enter the name of machine ('N') or ID of the machine ('I'):";
				cin >> C;

				if (C == 'n' || C == 'N')
				{
					machinenode* TE1;
					string MNAME;
					cout << "Enter the Name of the folder you want Routing table of : ";
					cin >> MNAME;
					TE1 = M.searchfolder(MNAME);
					cout << "The Routing/Finger table of the machine " << TE1->Machine_name << " :" << endl;
					TE1->FT->display();
				}
				else if (C == 'i' || C == 'I')
				{
					machinenode* TE1;
					int MAID;
					cout << "Enter the ID of the folder you want Routing table of : ";
					cin >> MAID;
					TE1 = M.IDfind(MAID);
					cout << "The Routing/Finger table of the machine " << TE1->Machine_name << " :" << endl;
					TE1->FT->display();
				}
			}
			else if (option == 8)
			{
				M.printing_all_active_machines();
			}
			else
			{
				cout << "Exiting" << endl;
				exitloop = false;
			}

			cout << endl << "Do you want to continue? (Y/N): ";
			char choiceE;
			cin >> choiceE;
			if (choiceE == 'N' || choiceE == 'n')
			{
				cout << "Exiting" << endl;
				exitloop = false;
				break;
			}
			system("cls");
		}
	}

	int calculateModMaxHash(const string& input)
	{
		int sum = 0;
		for (char c : input)
		{
			sum += static_cast<int>(c);
		}

		return sum % max_nom;
	}




};