#include<iostream>
#include<string>
#include <cstdlib> 
using namespace std;
#include"System.h"
int main()
{
	int btree_order = 0;

	int bitnum = 0;
	int no_of_machines = 0;

	cout << "Welcome to InterPlanetary File System (IPFS) " << endl << endl << endl;


	cout << "How many bits do u want the system to be? " << endl;
	cout << "Bits: ";
	cin >> bitnum;
	int max_machine = pow(2, bitnum);
	system("cls");
	cout << "Welcome to InterPlanetary File System (IPFS) " << endl << endl << endl;

	cout << "How many machines do u want in the system? " << endl;
	cout << "Machines: ";
	cin >> no_of_machines;
	while (no_of_machines > max_machine)
	{
		cout << "Error, Number of machines cannot exceed " << max_machine << endl;
		cout << "How many machines do u want? " << endl;
		cout << "Machines: ";
		cin >> no_of_machines;
	}
	system("cls");
	cout << "Welcome to InterPlanetary File System (IPFS) " << endl << endl << endl;
	cout << "Enter the order of B-Tree for file storage: ";
	cin >> btree_order;

	while (btree_order < 1)
	{
		cout << "Error, the order should be greater than zero" << endl;
		cout << endl << "Enter the order of B-Tree for file storage: ";
		cin >> btree_order;
	}

	system("cls");
	cout << "Welcome to InterPlanetary File System (IPFS) " << endl << endl << endl;

	cout << "The system has been created" << endl;
	cout << "\t\tNumber of bits:\t\t" << bitnum << endl;
	cout << "\t\tNumber of machines:\t" << no_of_machines << endl;

	char dummy;
	cout << endl << "Enter any key to continue..." << endl;
	cin >> dummy;
	system("cls");


	IPFS S1;

	S1.bitnum = bitnum;
	S1.BTREEOrder = btree_order;
	S1.no_of_machines = no_of_machines;
	S1.max_nom = max_machine;

	S1.main_loop_working();

	system("cls");
	cout << "Thank you for trying out our system!" << endl << endl<<endl;
	cout << "This system was made by:" << endl<<endl;
	cout << "Hammad Amer      22i-0877   CS-J" << endl;
	cout << "Shayaan Khalid   22i-0863   CS-J" << endl;
	return 0;
}