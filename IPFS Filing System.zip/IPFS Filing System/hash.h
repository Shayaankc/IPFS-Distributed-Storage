#pragma once
#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

class SHA1 {
public:
	SHA1()
	{
		reset();	//resets hash at start
	}

	void reset()	//reset ftn
	{
		hash[0] = 0x67452301;
		hash[1] = 0xEFCDAB89;
		hash[2] = 0x98BADCFE;
		hash[3] = 0x10325476;
		hash[4] = 0xC3D2E1F0;
		len_of_text = 0;
		size_of_buffer = 0;
	}
	void update(const  string& input_string)	//update hash with input string
	{
		update(reinterpret_cast<const unsigned char*>(input_string.data()), input_string.size());
	}
	string final() //mainftn to be used
	{
		unsigned char count_final[8];
		for (unsigned i = 0; i < 8; i++)
		{
			count_final[i] = static_cast<unsigned char>((len_of_text << 3) >> ((7 - i) * 8));
		}

		// padding the data
		update(reinterpret_cast<const unsigned char*>("\200"), 1);
		while (size_of_buffer != 56)
		{
			update(reinterpret_cast<const unsigned char*>("\0"), 1);
		}
		update(count_final, 8);

		ostringstream result;	//turn hash to string
		for (int i = 0; i < 5; i++)
		{
			result << hex << setfill('0') << setw(8) << hash[i];
		}

		reset();

		return result.str();	//final result
	}

	uint32_t hash[5];
	uint64_t len_of_text = 0;
	unsigned char buffer[64];
	size_t size_of_buffer = 0;

	void update(const unsigned char* data, size_t len) //updaye hash
	{
		len_of_text += len;
		while (len > 0)
		{
			size_t amount_to_copy = min(len, 64 - size_of_buffer);
			memcpy(buffer + size_of_buffer, data, amount_to_copy);

			size_of_buffer += amount_to_copy;
			data += amount_to_copy;
			len -= amount_to_copy;

			if (size_of_buffer == 64)
			{
				processBlock();
				size_of_buffer = 0;
			}
		}
	}

	void processBlock() //for 64-byte size
	{
		uint32_t w[80];
		for (int i = 0; i < 16; i++)
		{
			w[i] = (buffer[i * 4] << 24) | (buffer[i * 4 + 1] << 16) |
				(buffer[i * 4 + 2] << 8) | buffer[i * 4 + 3];
		}

		for (int i = 16; i < 80; i++)	//extend
		{
			w[i] = leftRotate(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1);
		}

		uint32_t a = hash[0];
		uint32_t b = hash[1];
		uint32_t c = hash[2];
		uint32_t d = hash[3];
		uint32_t e = hash[4];

		for (int i = 0; i < 80; i++)
		{
			uint32_t f, k;
			if (i < 20)
			{
				f = (b & c) | (~b & d);
				k = 0x5A827999;
			}
			else if (i < 40)
			{
				f = b ^ c ^ d;
				k = 0x6ED9EBA1;
			}
			else if (i < 60)
			{
				f = (b & c) | (b & d) | (c & d);
				k = 0x8F1BBCDC;
			}
			else
			{
				f = b ^ c ^ d;
				k = 0xCA62C1D6;
			}

			uint32_t temp = leftRotate(a, 5) + f + e + k + w[i];
			e = d;
			d = c;
			c = leftRotate(b, 30);
			b = a;
			a = temp;
		}

		//update value of hash
		hash[0] += a;
		hash[1] += b;
		hash[2] += c;
		hash[3] += d;
		hash[4] += e;
	}

	static uint32_t leftRotate(uint32_t val, int shifting)	//performs lft rotate on 32bit val
	{
		return (val << shifting) | (val >> (32 - shifting));
	}

	string calculateHash(const  string& input)	//finds hash of input string
	{
		reset();
		update(input);
		return final();
	}

};
string readFile(const  string& file_name)
{
	ifstream input_file(file_name);

	if (!input_file.is_open())
	{
		cerr << "Error opening file: " << file_name << endl;
		return ""; // return empty when erroe
	}

	string filedata;
	string line;

	while (getline(input_file, line))
	{
		filedata += line + "\n"; // add newline character to keep line breaks
	}

	if (input_file.bad())
	{
		cerr << "Error reading file: " << file_name << endl;
		input_file.close();
		return "";
	}

	input_file.close();

	return filedata;
}